import React from "react";
import ThemeToggle from "./ThemeToggle";

const Navbar = ({ theme, setTheme }) => {
  return (
    <div
      data-theme={theme}
      style={{
        backgroundColor: "var(--bg)",
        color: "var(--text)",
        borderBottom: "1px solid var(--text)",
        transition: "background-color 0.3s, color 0.3s",
      }}
      className="flex items-center justify-between px-6 py-4"
    >
      <h1 className="text-2xl font-bold">JSON Tree Viewer</h1>
      <ThemeToggle theme={theme} setTheme={setTheme} />
    </div>
  );
};

export default Navbar;


