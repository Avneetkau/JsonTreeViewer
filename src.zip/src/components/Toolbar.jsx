import React from "react";

export default function Toolbar({
  onVisualize,
  onClear,
  onSample,
  onDownload,
  onSearch,
  searchVal,
  setSearchVal,
  theme,
}) {
  const isDark = theme === "dark";

  return (
    <div
      data-theme={theme}
      style={{
        backgroundColor: "var(--bg)",
        color: "var(--text)",
        borderBottom: "1px solid var(--text)",
        transition: "background-color 0.3s, color 0.3s",
      }}
      className="flex items-center gap-2 px-4 py-1.5 m-0"
    >
      {/* Left buttons */}
      <div className="flex items-center gap-2">
        {/* ✅ Visualize (light mode fixed — no yellow hover) */}
        <button
          onClick={onVisualize}
          className="px-3 py-1 rounded border transition-all duration-300"
          style={{
            backgroundColor: "var(--btn-bg-visualize)",
            color: "var(--btn-text)",
            borderColor: "var(--btn-border-visualize)",
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg-visualize-hover)";
            if (isDark) {
              e.target.style.borderColor = "var(--btn-border-hover)";
              e.target.style.color = "var(--btn-text-hover)";
            } else {
              // Light mode — same as Find button (no yellow border or text)
              e.target.style.borderColor = "var(--btn-border-visualize)";
              e.target.style.color = "var(--btn-text)";
            }
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg-visualize)";
            e.target.style.borderColor = "var(--btn-border-visualize)";
            e.target.style.color = "var(--btn-text)";
          }}
        >
          Visualize
        </button>

        {/* Clear */}
        <button
          onClick={onClear}
          className="px-3 py-1 rounded border transition-all duration-300"
          style={{
            backgroundColor: "var(--btn-bg)",
            color: "var(--btn-text)",
            borderColor: "var(--btn-border)",
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg-hover)";
            if (isDark) {
              e.target.style.color = "var(--btn-text-hover)";
              e.target.style.borderColor = "var(--btn-border-hover)";
            }
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg)";
            e.target.style.color = "var(--btn-text)";
            e.target.style.borderColor = "var(--btn-border)";
          }}
        >
          Clear
        </button>

        {/* Sample */}
        <button
          onClick={onSample}
          className="px-3 py-1 rounded border transition-all duration-300"
          style={{
            backgroundColor: "var(--btn-bg)",
            color: "var(--btn-text)",
            borderColor: "var(--btn-border)",
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg-hover)";
            if (isDark) {
              e.target.style.color = "var(--btn-text-hover)";
              e.target.style.borderColor = "var(--btn-border-hover)";
            }
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg)";
            e.target.style.color = "var(--btn-text)";
            e.target.style.borderColor = "var(--btn-border)";
          }}
        >
          Sample
        </button>
      </div>

      {/* Search box */}
      <div className="ml-4 flex items-center gap-2 flex-1 max-w-md">
        <input
          value={searchVal}
          onChange={(e) => setSearchVal(e.target.value)}
          placeholder="Search path e.g. user.name"
          style={{
            backgroundColor: "var(--btn-bg)",
            color: "var(--text)",
            border: "1px solid var(--btn-border)",
            transition: "border-color 0.3s",
          }}
          className="flex-1 px-2 py-1 rounded"
          onMouseEnter={(e) => {
            if (isDark) {
              e.target.style.borderColor = "yellow"; // or var(--accent-yellow)
            }
          }}
          onMouseLeave={(e) => {
            e.target.style.borderColor = "var(--btn-border)";
          }}
        />

        <button
          onClick={() => onSearch(searchVal)}
          className="px-3 py-1 rounded border transition-all duration-300"
          style={{
            backgroundColor: "var(--btn-bg-visualize)",
            color: "var(--btn-text)",
            borderColor: "var(--btn-border-visualize)",
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg-visualize-hover)";
            if (isDark) {
              e.target.style.color = "var(--btn-text-hover)";
              e.target.style.borderColor = "var(--btn-border-hover)";
            } else {
              e.target.style.borderColor = "var(--btn-border-visualize)";
              e.target.style.color = "var(--btn-text)";
            }
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg-visualize)";
            e.target.style.color = "var(--btn-text)";
            e.target.style.borderColor = "var(--btn-border-visualize)";
          }}
        >
          Find
        </button>
      </div>

      {/* Export */}
      <div className="ml-auto flex items-center gap-2">
        <button
          onClick={onDownload}
          className="px-3 py-1 rounded border transition-all duration-300"
          style={{
            backgroundColor: "var(--btn-bg)",
            color: "var(--btn-text)",
            borderColor: "var(--btn-border)",
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg-hover)";
            if (isDark) {
              e.target.style.color = "var(--btn-text-hover)";
              e.target.style.borderColor = "var(--btn-border-hover)";
            }
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = "var(--btn-bg)";
            e.target.style.color = "var(--btn-text)";
            e.target.style.borderColor = "var(--btn-border)";
          }}
        >
          Export PNG
        </button>
      </div>
    </div>
  );
}
