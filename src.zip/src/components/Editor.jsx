import React, { useEffect, useRef, useState } from "react";
import sample from "../sample.json";

export default function Editor({ jsonText, setJsonText }) {
  const textRef = useRef(null);
  const [isDark, setIsDark] = useState(false);

  // Load default sample
  useEffect(() => {
    if (!jsonText) setJsonText(JSON.stringify(sample, null, 2));
  }, []);

  // Auto-resize textarea on JSON update
  useEffect(() => {
    if (textRef.current) {
      textRef.current.style.height = "auto";
      textRef.current.style.height = textRef.current.scrollHeight + "px";
    }
  }, [jsonText]);

  // Watch for theme changes
  useEffect(() => {
    const observer = new MutationObserver(() => {
      setIsDark(document.documentElement.classList.contains("dark"));
    });
    observer.observe(document.documentElement, { attributes: true });
    setIsDark(document.documentElement.classList.contains("dark"));
    return () => observer.disconnect();
  }, []);

  return (
    <div
      className={`w-96 border-r overflow-y-scroll transition-colors duration-300
      scrollbar scrollbar-thumb-rounded-md scrollbar-track-rounded-md
      ${isDark
        ? "bg-gray-900 text-gray-100 border-gray-700 scrollbar-thumb-gray-600 scrollbar-track-gray-800 hover:scrollbar-thumb-gray-400"
        : "bg-gray-50 text-gray-900 border-gray-200 scrollbar-thumb-gray-400 scrollbar-track-gray-100 hover:scrollbar-thumb-gray-500"
      }`}
    >
      {/* Header */}
      <div
        className={`flex items-center justify-between px-3 py-2 border-b transition-colors 
        ${isDark ? "border-gray-700" : "border-gray-200"}`}
      >
        <h2 className="font-semibold text-sm">JSON</h2>
      </div>

      {/* Textarea */}
      <div className="px-3 py-2">
        <textarea
          ref={textRef}
          value={jsonText}
          onChange={(e) => setJsonText(e.target.value)}
          className={`w-full min-h-[400px] resize-none outline-none border rounded-md p-2 text-sm font-mono transition-colors
          overflow-y-auto scrollbar scrollbar-thumb-rounded-md scrollbar-track-rounded-md
          ${isDark
            ? "bg-gray-800 border-gray-700 text-gray-100 scrollbar-thumb-gray-500 scrollbar-track-gray-900 hover:scrollbar-thumb-gray-400"
            : "bg-white border-gray-200 text-gray-900 scrollbar-thumb-gray-500 scrollbar-track-gray-100 hover:scrollbar-thumb-gray-600"
          }`}
          placeholder="Paste or write your JSON here..."
        />
      </div>

      {/* Footer */}
      <p
        className={`text-xs px-3 py-2 border-t transition-colors 
        ${isDark ? "text-gray-400 border-gray-700" : "text-gray-500 border-gray-200"}`}
      >
        Paste JSON and press <span className="font-semibold">Visualize</span>
      </p>
    </div>
  );
}
