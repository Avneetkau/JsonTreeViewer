export function parsePath(path) {
  if (!path) return [];
  let p = path.trim();
  if (p.startsWith("$")) p = p.slice(1);
  if (p.startsWith(".")) p = p.slice(1);
  const tokens = [];
  let cur = "";
  for (let i = 0; i < p.length; i++) {
    const ch = p[i];
    if (ch === ".") { if (cur) { tokens.push(cur); cur = ""; } }
    else if (ch === "[") {
      if (cur) { tokens.push(cur); cur = ""; }
      let j = i+1, num="";
      while (j < p.length && p[j] !== "]") { num += p[j]; j++; }
      i = j;
      if (num) tokens.push(num);
    } else cur += ch;
  }
  if (cur) tokens.push(cur);
  return tokens.filter(Boolean);
}
