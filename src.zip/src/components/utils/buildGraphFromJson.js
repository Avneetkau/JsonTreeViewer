// src/utils/buildGraphFromJson.js

export function buildGraphFromJson(obj, path = "$") {
  const nodes = [];
  const edges = [];

  function traverse(value, parentPath) {
    const entries = Array.isArray(value)
      ? value.map((v, i) => [i, v])
      : Object.entries(value);

    entries.forEach(([key, val]) => {
      const newPath = `${parentPath}.${key}`;
      const isObj = val !== null && typeof val === "object";
      const type = Array.isArray(val)
        ? "array"
        : isObj
        ? "object"
        : "primitive";

      // ✅ Create node
      nodes.push({
        id: newPath,
        data: { label: key, type, raw: val, path: newPath },
      });

      // ✅ Always create an edge (even for primitives)
      edges.push({
        id: `${parentPath}->${newPath}`,
        source: parentPath,
        target: newPath,
      });

      // ✅ Continue traversal only for objects/arrays
      if (isObj) traverse(val, newPath);
    });
  }

  // ✅ Add root node
  nodes.push({
    id: path,
    data: { label: "root", type: "object", path },
  });

  traverse(obj, path);
  return { nodes, edges };
}
