import dagre from "dagre";
const nodeWidth = 180, nodeHeight = 50;
export function getLayoutedElements(nodes, edges, direction = "TB") {
  const g = new dagre.graphlib.Graph();
  g.setDefaultEdgeLabel(() => ({}));
  g.setGraph({ rankdir: direction });
  nodes.forEach(n => g.setNode(n.id, { width: nodeWidth, height: nodeHeight }));
  edges.forEach(e => g.setEdge(e.source, e.target));
  dagre.layout(g);
  const isHorizontal = direction === "LR";
  const layoutedNodes = nodes.map(node => {
    const n = g.node(node.id);
    node.targetPosition = isHorizontal ? "left" : "top";
    node.sourcePosition = isHorizontal ? "right" : "bottom";
    node.position = { x: n.x - nodeWidth/2, y: n.y - nodeHeight/2 };
    return node;
  });
  return { nodes: layoutedNodes, edges };
}
