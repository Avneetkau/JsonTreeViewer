import React from "react";
export default function NodeRenderer({ data }) {
  const { label, type, raw } = data;
  const base = "px-3 py-2 rounded-lg rf-node-label";
  const classMap = {
    object: "bg-indigo-500 text-white",
    array: "bg-green-500 text-white",
    primitive: "bg-yellow-300 text-black",
    highlight: "bg-pink-500 text-white",
  };
  return (
    <div className={`${base} ${classMap[type] || ''}`} title={`Path: ${data.path}`}>
      <div>{label}</div>
      {type === "primitive" && <div className="text-xs opacity-90">{String(raw)}</div>}
    </div>
  );
}
