import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import ReactFlow, { Controls, MarkerType } from "reactflow";
import "reactflow/dist/style.css";
import { getLayoutedElements } from "./layout";
import { toPng } from "html-to-image";
import { saveAs } from "file-saver";
import NodeRenderer from "./NodeRenderer";

const Graph = forwardRef(({ nodesEdges, setNodesEdges, theme }, ref) => {
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const instanceRef = useRef(null);
  const wrapperRef = useRef(null);
  const [highlighted, setHighlighted] = useState(null);

  const isDark = theme === "dark";

  useEffect(() => {
    if (!nodesEdges || !nodesEdges.nodes) {
      setNodes([]);
      setEdges([]);
      return;
    }

    const mapped = nodesEdges.nodes.map((n) => ({
      ...n,
      data: { ...n.data },
      style: { borderRadius: 8, padding: 4 },
    }));

    const layouted = getLayoutedElements(mapped, nodesEdges.edges);
    setNodes(layouted.nodes);

    setEdges(
      layouted.edges.map((e) => ({
        ...e,
        id: `${e.id}-${isDark ? "dark" : "light"}`,
        style: {
          strokeWidth: 1.8, // No stroke color, let CSS handle it!
        },
        markerEnd: {
          type: MarkerType.Arrow,
          color: isDark ? "#ffffff" : "#000000",
        },
      }))
    );

    const t = setTimeout(() => {
      if (instanceRef.current) {
        instanceRef.current.fitView({
          padding: 0.3,
          duration: 400,
        });
      }
    }, 200);

    return () => clearTimeout(t);
  }, [nodesEdges, theme, isDark]);

  useImperativeHandle(ref, () => ({
    searchAndCenter: (id) => {
      if (!id) return;
      const found = nodes.find((n) => n.id === id);
      if (!found) {
        alert("No match");
        return;
      }
      setHighlighted(found.id);
      instanceRef.current.setCenter(found.position.x, found.position.y, {
        duration: 600,
        zoom: 1.1,
      });
    },

    exportPNG: async () => {
      if (!wrapperRef.current) return;
      try {
        const dataUrl = await toPng(wrapperRef.current, {
          cacheBust: true,
          backgroundColor: "#ffffff",
          pixelRatio: 2,
        });
        saveAs(dataUrl, "json-tree.png");
      } catch (e) {
        alert("Failed: " + e.message);
      }
    },
  }));

  const onNodeClick = (e, node) => {
    navigator.clipboard
      .writeText(node.data.path)
      .then(() => alert("Copied: " + node.data.path));
  };

  const buttonStyle = {
    backgroundColor: "var(--btn-bg)",
    color: "var(--text)",
    border: "1px solid var(--btn-border)",
    transition: "all 0.3s ease",
  };

  const nodeTypes = { custom: NodeRenderer };

  return (
    <div className="flex-1 relative" data-theme={theme}>
      <div className="absolute top-4 left-4 z-30 flex gap-2">
        {["Zoom In", "Zoom Out", "Fit"].map((label, i) => (
          <button
            key={label}
            className="px-2 py-1 rounded border transition-all duration-300"
            style={buttonStyle}
            onMouseEnter={(e) => {
              if (isDark) {
                e.target.style.borderColor = "var(--btn-border-hover)";
                e.target.style.color = "var(--btn-border-hover)";
              } else {
                e.target.style.borderColor = "var(--btn-border)";
                e.target.style.color = "var(--text)";
              }
            }}
            onMouseLeave={(e) => {
              e.target.style.borderColor = "var(--btn-border)";
              e.target.style.color = "var(--text)";
            }}
            onClick={() => {
              if (i === 0) instanceRef.current?.zoomIn?.();
              else if (i === 1) instanceRef.current?.zoomOut?.();
              else instanceRef.current?.fitView({ padding: 0.3, duration: 400 });
            }}
          >
            {label}
          </button>
        ))}
      </div>
      <div ref={wrapperRef} style={{ width: "100%", height: "100%" }}>
        <ReactFlow
          nodeTypes={nodeTypes}
          nodes={nodes.map((n) => ({
            ...n,
            type: "custom",
            data: {
              ...n.data,
              type: highlighted === n.id ? "highlight" : n.data.type,
            },
          }))}
          edges={edges}
          onInit={(rfi) => (instanceRef.current = rfi)}
          onNodeClick={onNodeClick}
          fitView
          minZoom={0.2}
          maxZoom={2}
          proOptions={{ hideAttribution: true }}
        >
          <Controls showInteractive={false} />
        </ReactFlow>
      </div>
    </div>
  );
});

export default Graph;
