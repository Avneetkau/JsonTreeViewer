import React, { useEffect, useRef, useState } from "react";
import Navbar from "./components/Navbar";
import Toolbar from "./components/Toolbar";
import Editor from "./components/Editor";
import Graph from "./components/Graph/Graph";
import { parsePath } from "./components/utils/pathParser";
import { buildGraphFromJson } from "./components/utils/buildGraphFromJson";

export default function App() {
  const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");
  const [jsonText, setJsonText] = useState("");
  const [nodesEdges, setNodesEdges] = useState({ nodes: [], edges: [] });
  const graphRef = useRef(null);
  const [searchVal, setSearchVal] = useState("");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
  }, [theme]);

  const handleVisualize = () => {
    try {
      const parsed = JSON.parse(jsonText);
      const ge = buildGraphFromJson(parsed);
      setNodesEdges(ge);
    } catch (e) {
      alert("Invalid JSON: " + e.message);
    }
  };

  const handleClear = () => setJsonText("");
  
  const handleSample = () => {
    fetch("/src/sample.json")
      .then((r) => r.json())
      .then((j) => setJsonText(JSON.stringify(j, null, 2)));
  };

  const handleSearch = (q) => {
    if (!q) return alert("Empty search");
    let qn = q.trim();
    if (!qn.startsWith("$")) qn = qn.startsWith(".") ? `$${qn}` : `$${"." + qn}`;
    const tokens = parsePath(qn);
    let canonical = "$";
    tokens.forEach((t) => (canonical += /^\d+$/.test(t) ? `[${t}]` : `.${t}`));
    graphRef.current?.searchAndCenter(canonical);
  };

  const handleExport = () => graphRef.current?.exportPNG();

  return (
    // Outer div with data-theme attribute for theme propagation
    <div
      data-theme={theme}
      className={`min-h-screen transition-colors duration-300 ${
        theme === "dark" ? "bg-gray-950 text-gray-100" : "bg-white text-gray-900"
      }`}
    >
      <Navbar theme={theme} setTheme={setTheme} />

      <Toolbar
        onVisualize={handleVisualize}
        onClear={handleClear}
        onSample={handleSample}
        onDownload={handleExport}
        theme={theme}
        onSearch={handleSearch}
        searchVal={searchVal}
        setSearchVal={setSearchVal}
      />

      <div className="flex flex-col md:flex-row h-[calc(100vh-120px)]">
        <Editor jsonText={jsonText} setJsonText={setJsonText} />
        <Graph
          ref={graphRef}
          nodesEdges={nodesEdges}
          setNodesEdges={setNodesEdges}
          theme={theme}
        />
      </div>
    </div>
  );
}
